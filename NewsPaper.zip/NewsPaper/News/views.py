from django.views.generic import ListView, UpdateView, CreateView, DetailView, DeleteView
from .models import Post, Category
from .filternews import PostFilter
from .NewsForm import PostCreateForm


class NewsPost(ListView):
    model = Post
    template_name = 'flatpages/news.html'
    context_object_name = 'News'
    queryset = Post.objects.order_by('-dateCreation')


class NewsID(DetailView):
    model = Post
    template_name = 'flatpages/NewsId.html'
    context_object_name = 'NewsId'


class PostPage(ListView):
    model = Post
    template_name = 'flatpages/news.html'
    context_object_name = 'News'
    ordering = ['-dateCreation']
    paginate_by = 1 #оставила 1 вместо 10 для наглядности, а то страницы пропадают, постов мало

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter'] = PostFilter(self.request.GET, queryset=self.get_queryset())

        context['categories'] = Category.objects.all()
        return context

    def post(self, request, *args, **kwargs):
        # берём значения для нового товара из POST-запроса отправленного на сервер
        author = request.POST['Author']
        title = request.POST['Title']
        category_id = request.POST['Category']
        text = request.POST['Text']

        post = Post(author=author, title=title, category_id=category_id, text=text)  # создаём новый товар и сохраняем
        post.save()
        return super().get(request, *args, **kwargs)  # отправляем пользователя обратно на GET-запрос.


class PostDetailView(DetailView):
    template_name = 'News_app/News_detail.html'
    queryset = Post.objects.all()


class NewsCreateView(CreateView):
    template_name = 'News_app/News_create.html'
    form_class = PostCreateForm


class NewsUpdateView(UpdateView):
    template_name = 'News_app/News_update.html'
    form_class = PostCreateForm

    # метод get_object мы используем вместо queryset, чтобы получить информацию об объекте, который мы собираемся редактировать
    def get_object(self, **kwargs):
        id = self.kwargs.get('pk')
        return Post.objects.get(pk=id)


class NewsDeleteView(DeleteView):
    template_name = 'News_app/News_delete.html'
    queryset = Post.objects.all()
    success_url = '/news/'
    context_object_name = 'News_delete'

